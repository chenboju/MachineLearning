#include <stdio.h>
void show(int,int,int *);
main(){
	int a=28,b=16,*ptr1,*ptr2;
	
	printf("&a=%2d,&b=%2d\n",a,b);
	
	ptr1=&b;
	ptr2=&a;
	
	*ptr1=4;
	show(a,b,ptr1,ptr2);
	a=16;
	show(a,b,ptr1,ptr2);
	*ptr2=12;
	show(a,b,ptr1,ptr2);
	ptr2=ptr1;
	show(a,b,ptr1,ptr2);
	*ptr1=19;
	show(a,b,ptr1,ptr2);
	ptr1=&a;
	show(a,b,ptr1,ptr2);
	a=7;
	show(a,b,ptr1,ptr2);
	*ptr2=*ptr1;
	show(a,b,ptr1,ptr2);
	
	
} 
void show(int a,int b,int *p1,int *p2){
	printf("a=%2d,b=%2d\n",a,b);
	printf("ptr1=%p, *ptr1=%2d",p1,*p1);
	printf("ptr2=%p, *ptr2=%2d\n",p2,*p2);
}
