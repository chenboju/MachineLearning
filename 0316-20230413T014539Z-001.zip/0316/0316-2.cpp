#include <stdio.h>
void show(int,int,int *);
main(){
	int a=12,b=7,*ptr;
	
	printf("a=%2d,b=%2d\n",a,b);
	printf("&a=%2d,&b=%2d\n",&a,&b);
	
	ptr=&a;
	show(a,b,ptr);
	*ptr=19;
	ptr=&b;
	show(a,b,ptr);
	*ptr=16;
	show(a,b,ptr);
	*ptr=12;
	show(a,b,ptr);
	*ptr=17;
	show(a,b,ptr);
	ptr=&a;
	show(a,b,ptr);
	a=b;
	show(a,b,ptr);
	*ptr=63;
	show(a,b,ptr);
	
	
} 
void show(int a,int b,int *pt){
	printf("a=%2d,b=%2d\n",a,b);
	printf("ptr=%d, *ptr=%2d\n",pt,*pt);
}
