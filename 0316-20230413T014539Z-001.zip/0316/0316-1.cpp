#include <stdio.h>
main(){
	float num=4.2f;
	int a1=4,a2=12;
	printf("num=%3.1f,address:%p\n",num,&num);
	printf("a1=%4d,address:%p\n",a1,&a1);
	printf("a1=%4d,address:%p\n",a2,&a2);
} 
